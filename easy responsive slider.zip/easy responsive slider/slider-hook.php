<?php 
/*
Plugin Name: easy Responsive Slider
Plugin URI: https://wordpress.org/plugins/easy-responsive-slider/ 
Description: Simple & lightweight responsive slider with shortcode.
Author: Ariful Islam
Author URI: http://arifislam.wix.com/portfolio
Version: 1.0
*/

// Calling latest jquery from wordpress.
function ers_call_latest_jquery_from_wordpress(){
	wp_enqueue_script('jquery');
}
add_action('init','ers_call_latest_jquery_from_wordpress');

//some set up
define('ERS_PLUGIN_PATH', WP_PLUGIN_URL. '/'. plugin_basename(dirname(__FILE__)).'/');

//Adding plugin javascript active file
wp_enqueue_script('ers_slider_main', ERS_PLUGIN_PATH.'js/responsiveslides.min.js', array('jquery') );
wp_enqueue_script('ers_slider_active', ERS_PLUGIN_PATH.'js/active.js', array('jquery') );
wp_enqueue_style('ers_slider_style', ERS_PLUGIN_PATH.'css/custom-style.css');

//Adding Shortcode
function ers_slider($atts, $content = null){
	
	return('<ul class="rslides">'.do_shortcode($content).'</ul>');
}
add_shortcode("ers_slider","ers_slider");

function ers_slides($atts,$content){
	
	return('<li><img src="'.$content.'" alt=""/></li>');
}
add_shortcode("ers_slides", "ers_slides");





?>