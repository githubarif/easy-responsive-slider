=== Easy Responsive Slider ===


Contributors: Ariful Islam
Author: Ariful Islam
Author URI: http://arifislam.wix.com/portfolio
Tags: Slider, Responsive, Responsive Slider, jquery, javascript, Smooth Navigation
Requires at least: 4.0 
Tested up to: 4.3.1
 
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0

Simple & lightweight responsive slider with shortcode.
== Description ==



Easy Responsive Slider is a Wordpress plugin to add Slider anywhere in your website using simple shortcode. Easy Responsive Slider is also responsible for your any screen size. Just use This Sortcode to display your slider anywhere in your website  [ers_slider][ers_slides]Your Image Link Here[/ers_slides][ers_slides]Your Image Link Here[/ers_slides][ers_slides]Your Image Link Here[/ers_slides][/ers_slider]
You can add image link from media section. Don't use space within shortcode. 
 
 == Installation ==


**Through Dashboard**

1. Log in to your WordPress admin panel and go to Plugins -> Add New
.2. Type **easy responsive slider** in the search box and click on search button.
3. Find easy responsive slider plugin.
4. Then click on Install and activate the plugin.
5. Now use this shortcode to display slider [ers_slider][ers_slides]Your Image Link Here[/ers_slides][ers_slides]Your Image Link Here[/ers_slides][ers_slides]Your Image Link Here[/ers_slides][/ers_slider] .6. Check out your slider. 

**Installing Via FTP**

1. Download the plugin to your hardisk.
2. Unzip.
3. Upload the "easy responsive slider" folder into your plugins directory.
4. Log in to your WordPress admin panel and click the Plugins menu.
5. Then activate the plugin.
6. Use shortcode and check
 slider.

== Screenshots ==


1. Adding shortcode in a post
2. Preview of the slider 

== Changelog ==

= 1.0 =
* First Release
