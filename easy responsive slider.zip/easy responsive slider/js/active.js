jQuery(function() {
    jQuery(".rslides").responsiveSlides();
  });